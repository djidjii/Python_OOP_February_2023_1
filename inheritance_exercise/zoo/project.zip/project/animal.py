class Animal:
    def __int__(self, name):
        self.name = name

