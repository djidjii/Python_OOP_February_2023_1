
class Food:
    def __int__(self, expiration_date: str):
        self.expiration_data = expiration_date
